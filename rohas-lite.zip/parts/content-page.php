<article <?php post_class('post single-post'); ?>>
	<div class="post_content">
		<div class="post_content">
			<h3><?php the_title(); ?></h3>
			<?php the_content(); ?>
		</div><!-- / .post_content -->
		
	</div><!-- / .post_content -->
</article><!-- / .post -->