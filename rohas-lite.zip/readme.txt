=== Rohas Lite ===
Contributors:		psdtohtmlguru
Tags: 				one-column, custom-header, featured-images, full-width-template, responsive-layout, custom-background, custom-menu, editor-style, threaded-comments, translation-ready
Requires at least:	3.3.0
Tested up to:		4.6

Rohas Lite
== Description ==
Rohas Lite is a modern blog responsive Wordpress Theme.

= License =
Font Awesome by @davegandy - http://fontawesome.io - @fontawesome
License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

SubtlePatterns
http://subtlepatterns.com/concrete-seamless/
http://subtlepatterns.com/concrete-wall/
License -  CC BY-SA 3.0 - Subtle Patterns © Atle Mo.

Unsplash - Ales Krivec
https://unsplash.com/search/winter?photo=gQR4STZ24kM
License - CC0 https://unsplash.com/license

Google Webfonts
Roboto - Open Source, Copyright 2011 Google Inc. All Rights Reserved.
Just Another Hand - Copyright (c) 2010 by Brian J. Bonislawsky DBA Astigmatic (AOETI). All rights reserved. Available under the Apache 2.0 licence.

= Hooks =
